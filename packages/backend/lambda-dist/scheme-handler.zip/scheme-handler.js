"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/handlers/scheme-handler.ts
var scheme_handler_exports = {};
__export(scheme_handler_exports, {
  addSchemeHandler: () => addSchemeHandler,
  discoverHandler: () => discoverHandler,
  handler: () => handler,
  listSchemesHandler: () => listSchemesHandler
});
module.exports = __toCommonJS(scheme_handler_exports);

// src/repositories/eligibility-rule-repository.ts
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var client = new import_client_dynamodb.DynamoDBClient({});
var docClient = import_lib_dynamodb.DynamoDBDocumentClient.from(client);
var TABLE_NAME = process.env.DYNAMODB_TABLE_NAME || "eligibility-mvp-table";
function toDynamoDBItem(rule) {
  const item = {
    PK: `RULE#${rule.id}`,
    SK: `SCHEME#${rule.schemeId}`,
    GSI1PK: `SCHEME#${rule.schemeId}`,
    GSI1SK: `CATEGORY#${rule.category}`,
    entityType: "ELIGIBILITY_RULE",
    rule
  };
  if (rule.applicableStates.length > 0) {
    item.GSI2PK = `STATE#${rule.applicableStates[0]}`;
    item.GSI2SK = `CATEGORY#${rule.category}`;
  }
  return item;
}
function fromDynamoDBItem(item) {
  return item.rule;
}
async function saveEligibilityRule(rule) {
  const item = toDynamoDBItem(rule);
  await docClient.send(
    new import_lib_dynamodb.PutCommand({
      TableName: TABLE_NAME,
      Item: item
    })
  );
}
async function getAllEligibilityRules() {
  const result = await docClient.send(
    new import_lib_dynamodb.ScanCommand({
      TableName: TABLE_NAME,
      FilterExpression: "entityType = :entityType",
      ExpressionAttributeValues: {
        ":entityType": "ELIGIBILITY_RULE"
      }
    })
  );
  if (!result.Items || result.Items.length === 0) {
    return [];
  }
  return result.Items.map((item) => fromDynamoDBItem(item));
}

// src/handlers/scheme-handler.ts
var import_client_bedrock_runtime = require("@aws-sdk/client-bedrock-runtime");
var bedrockClient = new import_client_bedrock_runtime.BedrockRuntimeClient({
  region: process.env.AWS_REGION || "ap-south-1"
});
var BEDROCK_MODEL_ID = "apac.amazon.nova-lite-v1:0";
function createResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Credentials": true
    },
    body: JSON.stringify(body)
  };
}
async function discoverSchemesWithClaude(query, category, state) {
  const prompt = `You are an expert at finding and structuring information about Indian government welfare schemes.

User Query: "${query}"
${category ? `Category Filter: ${category}` : ""}
${state ? `State Filter: ${state}` : ""}

Task:
Search for relevant government schemes based on the query. For each scheme you find, extract and structure the following information:

1. Scheme name (official name)
2. Brief description (2-3 sentences)
3. Category (education, employment, welfare, health, agriculture, etc.)
4. Target audience (who is it for?)
5. Eligibility criteria (age, income, location, etc.)
6. Required documents
7. Application process (online/offline/both)
8. Source URL (official government website)

Return your findings in this JSON format:
{
  "schemes": [
    {
      "name": "Scheme Name",
      "description": "Brief description",
      "category": "education",
      "targetAudience": ["students", "youth"],
      "eligibility": {
        "ageRange": ["18-25", "26-35"],
        "incomeLimit": "200000",
        "states": ["Karnataka", "All"],
        "otherCriteria": ["Must be enrolled in college"]
      },
      "documents": [
        "Aadhaar Card",
        "Income Certificate",
        "Educational Certificates"
      ],
      "applicationMode": "online",
      "sourceUrl": "https://official-website.gov.in",
      "confidence": 85
    }
  ],
  "totalFound": 3,
  "searchSummary": "Found 3 education schemes for students in Karnataka"
}

Important:
- Only include schemes from official government sources
- Provide accurate, verifiable information
- Include confidence score (0-100) for each scheme
- If you're unsure about details, indicate lower confidence
- Focus on currently active schemes

Respond with ONLY the JSON object, no additional text.`;
  const requestBody = {
    messages: [
      {
        role: "user",
        content: [{ text: prompt }]
      }
    ],
    inferenceConfig: {
      max_new_tokens: 4096,
      temperature: 0.3,
      top_p: 0.9
    }
  };
  const command = new import_client_bedrock_runtime.InvokeModelCommand({
    modelId: BEDROCK_MODEL_ID,
    contentType: "application/json",
    accept: "application/json",
    body: JSON.stringify(requestBody)
  });
  const response = await bedrockClient.send(command);
  const responseBody = JSON.parse(new TextDecoder().decode(response.body));
  if (responseBody.output?.message?.content && Array.isArray(responseBody.output.message.content)) {
    const textContent = responseBody.output.message.content.find((c) => c.text);
    if (textContent) {
      const text = textContent.text;
      let cleanedText = text.trim();
      if (cleanedText.startsWith("```json")) {
        cleanedText = cleanedText.replace(/```json\n?/g, "").replace(/```\n?/g, "");
      } else if (cleanedText.startsWith("```")) {
        cleanedText = cleanedText.replace(/```\n?/g, "");
      }
      const parsed = JSON.parse(cleanedText);
      return parsed.schemes || [];
    }
  }
  return [];
}
function convertToEligibilityRule(discoveredScheme) {
  const schemeId = `scheme-${discoveredScheme.name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`;
  const ruleId = `rule-${schemeId}-${Date.now()}`;
  const criteria = [];
  let criteriaIndex = 1;
  if (discoveredScheme.eligibility.ageRange) {
    criteria.push({
      id: `crit-age-${criteriaIndex++}`,
      field: "ageRange",
      operator: "in",
      value: discoveredScheme.eligibility.ageRange,
      weight: 0.2,
      description: `Age must be in range: ${discoveredScheme.eligibility.ageRange.join(", ")}`,
      mandatory: true
    });
  }
  if (discoveredScheme.eligibility.incomeLimit) {
    criteria.push({
      id: `crit-income-${criteriaIndex++}`,
      field: "incomeRange",
      operator: "lte",
      value: discoveredScheme.eligibility.incomeLimit,
      weight: 0.25,
      description: `Annual income must be below \u20B9${parseInt(discoveredScheme.eligibility.incomeLimit).toLocaleString("en-IN")}`,
      mandatory: true
    });
  }
  if (discoveredScheme.eligibility.states && discoveredScheme.eligibility.states.length > 0) {
    const states = discoveredScheme.eligibility.states.filter((s) => s !== "All");
    if (states.length > 0) {
      criteria.push({
        id: `crit-state-${criteriaIndex++}`,
        field: "location.state",
        operator: "in",
        value: states,
        weight: 0.2,
        description: `Must be resident of: ${states.join(", ")}`,
        mandatory: true
      });
    }
  }
  const requiredDocuments = (discoveredScheme.documents || []).map((doc, index) => ({
    type: doc.toLowerCase().replace(/\s+/g, "_"),
    name: doc,
    mandatory: index < 3,
    // First 3 are mandatory
    description: `${doc} for verification`
  }));
  const rule = {
    id: ruleId,
    schemeId,
    schemeName: discoveredScheme.name,
    schemeNameTranslations: {},
    description: discoveredScheme.description,
    descriptionTranslations: {},
    category: discoveredScheme.category || "general",
    targetAudience: discoveredScheme.targetAudience || [],
    criteria,
    requiredDocuments,
    applicableStates: discoveredScheme.eligibility.states || [],
    ruralUrbanFilter: "both",
    isOpenEnded: true,
    processingTime: "30-45 days",
    applicationMode: discoveredScheme.applicationMode || "online",
    applicationUrl: discoveredScheme.sourceUrl,
    trustLevel: "unverifiable",
    sourceUrl: discoveredScheme.sourceUrl,
    lastVerified: (/* @__PURE__ */ new Date()).toISOString(),
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  return rule;
}
async function discoverHandler(event) {
  try {
    const body = JSON.parse(event.body || "{}");
    const { query, category, state } = body;
    if (!query || typeof query !== "string") {
      return createResponse(400, {
        error: "Missing required field: query"
      });
    }
    console.log(`Discovering schemes for query: "${query}"`);
    const discoveredSchemes = await discoverSchemesWithClaude(query, category, state);
    return createResponse(200, {
      success: true,
      data: {
        schemes: discoveredSchemes,
        totalFound: discoveredSchemes.length,
        query
      }
    });
  } catch (error) {
    console.error("Error discovering schemes:", error);
    return createResponse(500, {
      error: "Internal server error",
      message: error instanceof Error ? error.message : "Unknown error"
    });
  }
}
async function addSchemeHandler(event) {
  try {
    const body = JSON.parse(event.body || "{}");
    const { scheme } = body;
    if (!scheme) {
      return createResponse(400, {
        error: "Missing required field: scheme"
      });
    }
    const rule = convertToEligibilityRule(scheme);
    const existingRules = await getAllEligibilityRules();
    const duplicate = existingRules.find(
      (r) => r.schemeName.toLowerCase().trim() === rule.schemeName.toLowerCase().trim()
    );
    if (duplicate) {
      return createResponse(409, {
        error: "Scheme already exists",
        message: `A scheme with the name "${rule.schemeName}" has already been added to the database.`,
        existingSchemeId: duplicate.schemeId
      });
    }
    await saveEligibilityRule(rule);
    console.log(`Added scheme: ${rule.schemeName} (${rule.schemeId})`);
    return createResponse(200, {
      success: true,
      data: {
        message: "Scheme added successfully",
        schemeId: rule.schemeId,
        schemeName: rule.schemeName
      }
    });
  } catch (error) {
    console.error("Error adding scheme:", error);
    return createResponse(500, {
      error: "Internal server error",
      message: error instanceof Error ? error.message : "Unknown error"
    });
  }
}
async function listSchemesHandler(_event) {
  try {
    const rules = await getAllEligibilityRules();
    const schemes = rules.map((rule) => ({
      id: rule.schemeId,
      name: rule.schemeName,
      description: rule.description,
      category: rule.category,
      targetAudience: rule.targetAudience
    }));
    return createResponse(200, {
      success: true,
      data: {
        schemes,
        total: schemes.length
      }
    });
  } catch (error) {
    console.error("Error listing schemes:", error);
    return createResponse(500, {
      error: "Internal server error",
      message: error instanceof Error ? error.message : "Unknown error"
    });
  }
}
async function handler(event) {
  const method = event.httpMethod;
  const path = event.path;
  console.log(`${method} ${path}`);
  try {
    if (method === "POST" && path.endsWith("/discover")) {
      return await discoverHandler(event);
    } else if (method === "POST" && path.endsWith("/add")) {
      return await addSchemeHandler(event);
    } else if (method === "GET" && path.endsWith("/list")) {
      return await listSchemesHandler(event);
    } else {
      return createResponse(404, {
        error: "Not found",
        message: `No handler for ${method} ${path}`
      });
    }
  } catch (error) {
    console.error("Unhandled error in main handler:", error);
    return createResponse(500, {
      error: "Internal server error",
      message: error instanceof Error ? error.message : "Unknown error"
    });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  addSchemeHandler,
  discoverHandler,
  handler,
  listSchemesHandler
});
