"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/handlers/profile-handler.ts
var profile_handler_exports = {};
__export(profile_handler_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(profile_handler_exports);

// src/repositories/user-profile-repository.ts
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");

// ../../node_modules/uuid/dist/esm-node/rng.js
var import_crypto = __toESM(require("crypto"));
var rnds8Pool = new Uint8Array(256);
var poolPtr = rnds8Pool.length;
function rng() {
  if (poolPtr > rnds8Pool.length - 16) {
    import_crypto.default.randomFillSync(rnds8Pool);
    poolPtr = 0;
  }
  return rnds8Pool.slice(poolPtr, poolPtr += 16);
}

// ../../node_modules/uuid/dist/esm-node/stringify.js
var byteToHex = [];
for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 256).toString(16).slice(1));
}
function unsafeStringify(arr, offset = 0) {
  return byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]];
}

// ../../node_modules/uuid/dist/esm-node/native.js
var import_crypto2 = __toESM(require("crypto"));
var native_default = {
  randomUUID: import_crypto2.default.randomUUID
};

// ../../node_modules/uuid/dist/esm-node/v4.js
function v4(options, buf, offset) {
  if (native_default.randomUUID && !buf && !options) {
    return native_default.randomUUID();
  }
  options = options || {};
  const rnds = options.random || (options.rng || rng)();
  rnds[6] = rnds[6] & 15 | 64;
  rnds[8] = rnds[8] & 63 | 128;
  if (buf) {
    offset = offset || 0;
    for (let i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }
    return buf;
  }
  return unsafeStringify(rnds);
}
var v4_default = v4;

// src/repositories/user-profile-repository.ts
var client = new import_client_dynamodb.DynamoDBClient({});
var docClient = import_lib_dynamodb.DynamoDBDocumentClient.from(client);
var TABLE_NAME = process.env.TABLE_NAME || "eligibility-mvp-table";
function toDynamoDBItem(profile) {
  return {
    PK: `USER#${profile.id}`,
    SK: "PROFILE",
    GSI1PK: `PHONE#${profile.phoneNumber}`,
    GSI1SK: "PROFILE",
    EntityType: "UserProfile",
    id: profile.id,
    phoneNumber: profile.phoneNumber,
    email: profile.email,
    name: profile.name,
    aadhaarHash: profile.aadhaarHash,
    ageRange: profile.ageRange,
    gender: profile.gender,
    location: profile.location,
    education: profile.education,
    occupation: profile.occupation,
    employmentStatus: profile.employmentStatus,
    incomeRange: profile.incomeRange,
    category: profile.category,
    disabilityStatus: profile.disabilityStatus,
    language: profile.language,
    interactionMode: profile.interactionMode || "text",
    explanationLevel: profile.explanationLevel || "standard",
    consentGiven: profile.consentGiven,
    consentTimestamp: profile.consentTimestamp?.toISOString(),
    sensitiveDataConsent: profile.sensitiveDataConsent,
    createdAt: profile.createdAt.toISOString(),
    updatedAt: profile.updatedAt.toISOString()
  };
}
function fromDynamoDBItem(item) {
  return {
    id: item.id,
    phoneNumber: item.phoneNumber,
    email: item.email,
    name: item.name,
    aadhaarHash: item.aadhaarHash,
    ageRange: item.ageRange,
    gender: item.gender,
    location: {
      state: item.location.state,
      district: item.location.district,
      ruralUrban: item.location.ruralUrban,
      pincode: item.location.pincode
    },
    education: item.education,
    occupation: item.occupation,
    employmentStatus: item.employmentStatus,
    incomeRange: item.incomeRange,
    category: item.category,
    disabilityStatus: item.disabilityStatus,
    language: item.language,
    interactionMode: item.interactionMode,
    explanationLevel: item.explanationLevel,
    consentGiven: item.consentGiven,
    consentTimestamp: item.consentTimestamp ? new Date(item.consentTimestamp) : void 0,
    sensitiveDataConsent: item.sensitiveDataConsent,
    createdAt: new Date(item.createdAt),
    updatedAt: new Date(item.updatedAt)
  };
}
var UserProfileRepository = class {
  async create(input) {
    const now = /* @__PURE__ */ new Date();
    const profile = {
      id: v4_default(),
      phoneNumber: input.phoneNumber,
      email: input.email,
      name: input.name,
      ageRange: input.ageRange,
      location: input.location,
      language: input.language,
      consentGiven: input.consentGiven,
      consentTimestamp: now,
      gender: input.gender,
      education: input.education,
      occupation: input.occupation,
      employmentStatus: input.employmentStatus,
      incomeRange: input.incomeRange,
      category: input.category,
      disabilityStatus: input.disabilityStatus,
      interactionMode: input.interactionMode || "text",
      explanationLevel: input.explanationLevel || "standard",
      sensitiveDataConsent: input.sensitiveDataConsent,
      createdAt: now,
      updatedAt: now
    };
    const item = toDynamoDBItem(profile);
    await docClient.send(
      new import_lib_dynamodb.PutCommand({
        TableName: TABLE_NAME,
        Item: item
      })
    );
    return profile;
  }
  async getById(userId) {
    const result = await docClient.send(
      new import_lib_dynamodb.GetCommand({
        TableName: TABLE_NAME,
        Key: {
          PK: `USER#${userId}`,
          SK: "PROFILE"
        }
      })
    );
    if (!result.Item) {
      return null;
    }
    return fromDynamoDBItem(result.Item);
  }
  async getByPhoneNumber(phoneNumber) {
    const result = await docClient.send(
      new import_lib_dynamodb.QueryCommand({
        TableName: TABLE_NAME,
        IndexName: "GSI1",
        KeyConditionExpression: "GSI1PK = :gsi1pk AND GSI1SK = :gsi1sk",
        ExpressionAttributeValues: {
          ":gsi1pk": `PHONE#${phoneNumber}`,
          ":gsi1sk": "PROFILE"
        },
        Limit: 1
      })
    );
    if (!result.Items || result.Items.length === 0) {
      return null;
    }
    return fromDynamoDBItem(result.Items[0]);
  }
  async update(input) {
    const existing = await this.getById(input.id);
    if (!existing) {
      return null;
    }
    const now = /* @__PURE__ */ new Date();
    const updated = {
      ...existing,
      ...input,
      location: input.location ? { ...existing.location, ...input.location } : existing.location,
      sensitiveDataConsent: input.sensitiveDataConsent ? { ...existing.sensitiveDataConsent, ...input.sensitiveDataConsent } : existing.sensitiveDataConsent,
      updatedAt: now
    };
    const item = toDynamoDBItem(updated);
    await docClient.send(
      new import_lib_dynamodb.PutCommand({
        TableName: TABLE_NAME,
        Item: item
      })
    );
    return updated;
  }
  async delete(userId) {
    try {
      await docClient.send(
        new import_lib_dynamodb.DeleteCommand({
          TableName: TABLE_NAME,
          Key: {
            PK: `USER#${userId}`,
            SK: "PROFILE"
          }
        })
      );
      return true;
    } catch (error) {
      console.error("Error deleting user profile:", error);
      return false;
    }
  }
  async exists(userId) {
    const profile = await this.getById(userId);
    return profile !== null;
  }
  async phoneNumberExists(phoneNumber) {
    const profile = await this.getByPhoneNumber(phoneNumber);
    return profile !== null;
  }
};

// src/utils/validation.ts
var VALID_AGE_RANGES = ["18-25", "26-35", "36-45", "46-60", "60+"];
var VALID_GENDERS = ["male", "female", "other", "prefer_not_to_say"];
var VALID_RURAL_URBAN = ["rural", "urban"];
var VALID_EDUCATION = ["no_formal", "primary", "secondary", "graduate", "postgraduate"];
var VALID_EMPLOYMENT_STATUS = ["employed", "unemployed", "self_employed", "student", "retired"];
var VALID_INCOME_RANGES = ["below_50k", "50k_1l", "1l_2l", "2l_5l", "above_5l"];
var VALID_CATEGORIES = ["general", "obc", "sc", "st", "ews"];
var VALID_DISABILITY_STATUS = ["none", "physical", "visual", "hearing", "other"];
var VALID_INTERACTION_MODES = ["voice", "text"];
var VALID_EXPLANATION_LEVELS = ["standard", "very_simple"];
var PHONE_NUMBER_REGEX = /^\+?[1-9]\d{9,14}$/;
var PINCODE_REGEX = /^\d{6}$/;
function validateCreateUserProfile(input) {
  const errors = [];
  if (!input.phoneNumber) {
    errors.push({ field: "phoneNumber", message: "Phone number is required" });
  } else if (!PHONE_NUMBER_REGEX.test(input.phoneNumber)) {
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (!uuidRegex.test(input.phoneNumber)) {
      errors.push({ field: "phoneNumber", message: "Invalid phone number format" });
    }
  }
  if (!input.ageRange) {
    errors.push({ field: "ageRange", message: "Age range is required" });
  } else if (!VALID_AGE_RANGES.includes(input.ageRange)) {
    errors.push({ field: "ageRange", message: "Invalid age range" });
  }
  if (!input.location) {
    errors.push({ field: "location", message: "Location is required" });
  } else {
    if (!input.location.state) {
      errors.push({ field: "location.state", message: "State is required" });
    }
    if (!input.location.district) {
      errors.push({ field: "location.district", message: "District is required" });
    }
    if (!input.location.ruralUrban) {
      errors.push({ field: "location.ruralUrban", message: "Rural/Urban classification is required" });
    } else if (!VALID_RURAL_URBAN.includes(input.location.ruralUrban)) {
      errors.push({ field: "location.ruralUrban", message: "Invalid rural/urban classification" });
    }
    if (input.location.pincode && !PINCODE_REGEX.test(input.location.pincode)) {
      errors.push({ field: "location.pincode", message: "Invalid pincode format" });
    }
  }
  if (!input.language) {
    errors.push({ field: "language", message: "Language preference is required" });
  }
  if (input.consentGiven === void 0 || input.consentGiven === null) {
    errors.push({ field: "consentGiven", message: "Consent is required" });
  } else if (!input.consentGiven) {
    errors.push({ field: "consentGiven", message: "User must provide consent to use the platform" });
  }
  if (input.gender && !VALID_GENDERS.includes(input.gender)) {
    errors.push({ field: "gender", message: "Invalid gender value" });
  }
  if (input.education && !VALID_EDUCATION.includes(input.education)) {
    errors.push({ field: "education", message: "Invalid education value" });
  }
  if (input.employmentStatus && !VALID_EMPLOYMENT_STATUS.includes(input.employmentStatus)) {
    errors.push({ field: "employmentStatus", message: "Invalid employment status" });
  }
  if (input.incomeRange && !VALID_INCOME_RANGES.includes(input.incomeRange)) {
    errors.push({ field: "incomeRange", message: "Invalid income range" });
  }
  if (input.category && !VALID_CATEGORIES.includes(input.category)) {
    errors.push({ field: "category", message: "Invalid category value" });
  }
  if (input.disabilityStatus && !VALID_DISABILITY_STATUS.includes(input.disabilityStatus)) {
    errors.push({ field: "disabilityStatus", message: "Invalid disability status" });
  }
  if (input.interactionMode && !VALID_INTERACTION_MODES.includes(input.interactionMode)) {
    errors.push({ field: "interactionMode", message: "Invalid interaction mode" });
  }
  if (input.explanationLevel && !VALID_EXPLANATION_LEVELS.includes(input.explanationLevel)) {
    errors.push({ field: "explanationLevel", message: "Invalid explanation level" });
  }
  if (input.category && (!input.sensitiveDataConsent || !input.sensitiveDataConsent.category)) {
    errors.push({ field: "sensitiveDataConsent.category", message: "Consent required for category information" });
  }
  if (input.disabilityStatus && input.disabilityStatus !== "none" && (!input.sensitiveDataConsent || !input.sensitiveDataConsent.disability)) {
    errors.push({ field: "sensitiveDataConsent.disability", message: "Consent required for disability information" });
  }
  if (input.incomeRange && (!input.sensitiveDataConsent || !input.sensitiveDataConsent.income)) {
    errors.push({ field: "sensitiveDataConsent.income", message: "Consent required for income information" });
  }
  return {
    isValid: errors.length === 0,
    errors
  };
}
function validateUpdateUserProfile(input) {
  const errors = [];
  if (!input.id) {
    errors.push({ field: "id", message: "User ID is required for updates" });
  }
  if (input.ageRange && !VALID_AGE_RANGES.includes(input.ageRange)) {
    errors.push({ field: "ageRange", message: "Invalid age range" });
  }
  if (input.gender && !VALID_GENDERS.includes(input.gender)) {
    errors.push({ field: "gender", message: "Invalid gender value" });
  }
  if (input.location) {
    if (input.location.state !== void 0 && !input.location.state.trim()) {
      errors.push({ field: "location.state", message: "State cannot be empty" });
    }
    if (input.location.district !== void 0 && !input.location.district.trim()) {
      errors.push({ field: "location.district", message: "District cannot be empty" });
    }
    if (input.location.ruralUrban && !VALID_RURAL_URBAN.includes(input.location.ruralUrban)) {
      errors.push({ field: "location.ruralUrban", message: "Invalid rural/urban classification" });
    }
    if (input.location.pincode && !PINCODE_REGEX.test(input.location.pincode)) {
      errors.push({ field: "location.pincode", message: "Invalid pincode format" });
    }
  }
  if (input.education && !VALID_EDUCATION.includes(input.education)) {
    errors.push({ field: "education", message: "Invalid education value" });
  }
  if (input.employmentStatus && !VALID_EMPLOYMENT_STATUS.includes(input.employmentStatus)) {
    errors.push({ field: "employmentStatus", message: "Invalid employment status" });
  }
  if (input.incomeRange && !VALID_INCOME_RANGES.includes(input.incomeRange)) {
    errors.push({ field: "incomeRange", message: "Invalid income range" });
  }
  if (input.category && !VALID_CATEGORIES.includes(input.category)) {
    errors.push({ field: "category", message: "Invalid category value" });
  }
  if (input.disabilityStatus && !VALID_DISABILITY_STATUS.includes(input.disabilityStatus)) {
    errors.push({ field: "disabilityStatus", message: "Invalid disability status" });
  }
  if (input.interactionMode && !VALID_INTERACTION_MODES.includes(input.interactionMode)) {
    errors.push({ field: "interactionMode", message: "Invalid interaction mode" });
  }
  if (input.explanationLevel && !VALID_EXPLANATION_LEVELS.includes(input.explanationLevel)) {
    errors.push({ field: "explanationLevel", message: "Invalid explanation level" });
  }
  return {
    isValid: errors.length === 0,
    errors
  };
}

// src/handlers/profile-handler.ts
var repository = new UserProfileRepository();
function createResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Credentials": true
    },
    body: JSON.stringify(body)
  };
}
function createErrorResponse(statusCode, message, errors) {
  return createResponse(statusCode, {
    error: message,
    ...errors && { details: errors }
  });
}
async function handler(event) {
  console.log("Event:", JSON.stringify(event, null, 2));
  const httpMethod = event.httpMethod;
  const path = event.path;
  const pathParameters = event.pathParameters || {};
  try {
    if (httpMethod === "POST" && path.endsWith("/profiles")) {
      return await handleCreateProfile(event);
    }
    if (httpMethod === "GET" && pathParameters.userId && !path.includes("/phone/")) {
      return await handleGetProfile(pathParameters.userId);
    }
    if (httpMethod === "GET" && path.includes("/phone/") && pathParameters.phoneNumber) {
      return await handleGetProfileByPhone(pathParameters.phoneNumber);
    }
    if (httpMethod === "PUT" && pathParameters.userId) {
      return await handleUpdateProfile(event, pathParameters.userId);
    }
    if (httpMethod === "DELETE" && pathParameters.userId) {
      return await handleDeleteProfile(pathParameters.userId);
    }
    return createErrorResponse(404, "Not Found");
  } catch (error) {
    console.error("Error:", error);
    return createErrorResponse(500, "Internal Server Error", error instanceof Error ? error.message : "Unknown error");
  }
}
async function handleCreateProfile(event) {
  if (!event.body) {
    return createErrorResponse(400, "Request body is required");
  }
  let input;
  try {
    input = JSON.parse(event.body);
  } catch (error) {
    return createErrorResponse(400, "Invalid JSON in request body");
  }
  const validation = validateCreateUserProfile(input);
  if (!validation.isValid) {
    return createErrorResponse(400, "Validation failed", validation.errors);
  }
  const existingProfile = await repository.getByPhoneNumber(input.phoneNumber);
  if (existingProfile) {
    return createErrorResponse(409, "A profile with this phone number already exists", {
      existingUserId: existingProfile.id
    });
  }
  const profile = await repository.create(input);
  return createResponse(201, {
    message: "Profile created successfully",
    profile
  });
}
async function handleGetProfile(userId) {
  const profile = await repository.getById(userId);
  if (!profile) {
    return createErrorResponse(404, "Profile not found");
  }
  return createResponse(200, {
    profile
  });
}
async function handleGetProfileByPhone(phoneNumber) {
  const decodedPhoneNumber = decodeURIComponent(phoneNumber);
  const profile = await repository.getByPhoneNumber(decodedPhoneNumber);
  if (!profile) {
    return createErrorResponse(404, "Profile not found");
  }
  return createResponse(200, {
    profile
  });
}
async function handleUpdateProfile(event, userId) {
  if (!event.body) {
    return createErrorResponse(400, "Request body is required");
  }
  let input;
  try {
    input = JSON.parse(event.body);
  } catch (error) {
    return createErrorResponse(400, "Invalid JSON in request body");
  }
  const updateInput = {
    ...input,
    id: userId
  };
  const validation = validateUpdateUserProfile(updateInput);
  if (!validation.isValid) {
    return createErrorResponse(400, "Validation failed", validation.errors);
  }
  const profile = await repository.update(updateInput);
  if (!profile) {
    return createErrorResponse(404, "Profile not found");
  }
  return createResponse(200, {
    message: "Profile updated successfully",
    profile
  });
}
async function handleDeleteProfile(userId) {
  const success = await repository.delete(userId);
  if (!success) {
    return createErrorResponse(404, "Profile not found or could not be deleted");
  }
  return createResponse(200, {
    message: "Profile deleted successfully"
  });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
